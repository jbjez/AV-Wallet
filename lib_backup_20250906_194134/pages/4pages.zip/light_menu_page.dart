import 'package:flutter/material.dart';
import 'dart:math';
import 'home_page.dart';
import 'catalogue_page.dart';
import 'structure_menu_page.dart';
import 'sound_menu_page.dart';
import 'video_menu_page.dart';
import 'electricite_menu_page.dart';
import 'divers_menu_page.dart';
import 'ar_measure_page.dart';

class LightMenuPage extends StatefulWidget {
  const LightMenuPage({super.key});

  @override
  State<LightMenuPage> createState() => _LightMenuPageState();
}

class _LightMenuPageState extends State<LightMenuPage> {
  double angle = 35;
  double height = 10;
  double distance = 20;

  double get diameter {
    double rad = angle * pi / 180;
    double hypotenuse = sqrt(pow(height, 2) + pow(distance, 2));
    return 2 * (hypotenuse * tan(rad / 2));
  }

  void _navigateTo(Widget page) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: Container(
          color: Colors.black.withOpacity(0.4),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
              const Text(
                'Lumière',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          Opacity(
            opacity: 0.5,
            child: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/background.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 6),
                GestureDetector(
                  onTap: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => const HomePage()),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.4),
                      border: Border.all(color: Colors.white, width: 2),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Image.asset('assets/logo.png', height: 60),
                  ),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: DefaultTabController(
                    length: 2,
                    child: Column(
                      children: [
                        const TabBar(
                          tabs: [
                            Tab(text: 'Calcul Faisceau'),
                            Tab(text: 'Calcul Driver LED'),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Expanded(
                          child: TabBarView(
                            children: [
                              SingleChildScrollView(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text('Angle (1° à 70°)'),
                                    Slider(
                                      min: 1,
                                      max: 70,
                                      divisions: 69,
                                      value: angle,
                                      label: '${angle.round()}°',
                                      onChanged: (value) => setState(() => angle = value),
                                    ),
                                    const SizedBox(height: 8),
                                    const Text('Hauteur (1m à 20m)'),
                                    Slider(
                                      min: 1,
                                      max: 20,
                                      divisions: 19,
                                      value: height,
                                      label: '${height.round()}m',
                                      onChanged: (value) => setState(() => height = value),
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text('Distance (1m à 40m)'),
                                        GestureDetector(
                                          onTap: () {
                                            _navigateTo(const ArMeasurePage());
                                          },
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                            decoration: BoxDecoration(
                                              color: Colors.white.withOpacity(0.2),
                                              border: Border.all(color: Colors.white, width: 1),
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            child: const Text(
                                              'Mesurer votre distance',
                                              style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Slider(
                                      min: 1,
                                      max: 40,
                                      divisions: 39,
                                      value: distance,
                                      label: '${distance.round()}m',
                                      onChanged: (value) => setState(() => distance = value),
                                    ),
                                    const SizedBox(height: 16),
                                    Container(
                                      padding: const EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF0A1128).withOpacity(0.5),
                                        border: Border.all(color: Color(0xFF0A1128), width: 2),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        'Diamètre du faisceau : ${diameter.toStringAsFixed(2)} m',
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Center(child: Text('Formulaire Calcul Driver LED')),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blueGrey[900],
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.grey,
        currentIndex: 1,
        onTap: (index) {
          switch (index) {
            case 0:
              _navigateTo(const CataloguePage());
              break;
            case 1:
              _navigateTo(const LightMenuPage());
              break;
            case 2:
              _navigateTo(const StructureMenuPage());
              break;
            case 3:
              _navigateTo(const SoundMenuPage());
              break;
            case 4:
              _navigateTo(const VideoMenuPage());
              break;
            case 5:
              _navigateTo(const ElectriciteMenuPage());
              break;
            case 6:
              _navigateTo(const DiversMenuPage());
              break;
          }
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
          BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
          BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
          BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
          BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
          BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
          BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
        ],
      ),
    );
  }
}
