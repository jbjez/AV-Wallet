import 'package:flutter/material.dart';
import '../models/catalogue_item.dart';
import '../data/catalogue_data.dart';
import 'home_page.dart';
import 'light_menu_page.dart';
import 'structure_menu_page.dart';
import 'sound_menu_page.dart';
import 'video_menu_page.dart';
import 'electricite_menu_page.dart';
import 'divers_menu_page.dart';

class CataloguePage extends StatefulWidget {
  const CataloguePage({super.key});

  @override
  State<CataloguePage> createState() => _CataloguePageState();
}

class _CataloguePageState extends State<CataloguePage> {
  String? selectedCategory;
  String? selectedBrand;
  String? selectedProduct;

  List<String> getCategories() {
    return catalogueData.map((item) => item.categorie).toSet().toList();
  }

  List<String> getBrandsForCategory(String category) {
    return catalogueData
        .where((item) => item.categorie == category)
        .map((item) => item.marque)
        .toSet()
        .toList();
  }

  List<String> getProductsForBrand(String brand) {
    return catalogueData
        .where((item) => item.marque == brand && (selectedCategory == null || item.categorie == selectedCategory))
        .map((item) => item.produit)
        .toList();
  }

  CatalogueItem? getSelectedItem() {
    return catalogueData.firstWhere(
      (item) =>
          item.produit == selectedProduct &&
          item.marque == selectedBrand &&
          item.categorie == selectedCategory,
      orElse: () => CatalogueItem(categorie: '', marque: '', produit: '', dimensions: '', poids: '', conso: ''),
    );
  }

  void _navigateTo(Widget page) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: Container(
          color: Colors.black.withOpacity(0.4),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
              const Text(
                'Catalogue',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          Opacity(
            opacity: 0.5,
            child: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/background.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 6),
                GestureDetector(
                  onTap: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => const HomePage()),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.4),
                      border: Border.all(color: Colors.white, width: 2),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Image.asset('assets/logo.png', height: 60),
                  ),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          DropdownButton<String>(
                            value: selectedCategory,
                            hint: const Text('Choisir une catégorie'),
                            dropdownColor: Colors.blueGrey[900],
                            style: const TextStyle(color: Colors.white),
                            isExpanded: true,
                            items: getCategories()
                                .map((category) => DropdownMenuItem<String>(
                                      value: category,
                                      child: Text(category),
                                    ))
                                .toList(),
                            onChanged: (value) {
                              setState(() {
                                selectedCategory = value;
                                selectedBrand = null;
                                selectedProduct = null;
                              });
                            },
                          ),
                          const SizedBox(height: 10),
                          if (selectedCategory != null)
                            DropdownButton<String>(
                              value: selectedBrand,
                              hint: const Text('Choisir une marque'),
                              dropdownColor: Colors.blueGrey[900],
                              style: const TextStyle(color: Colors.white),
                              isExpanded: true,
                              items: getBrandsForCategory(selectedCategory!)
                                  .map((brand) => DropdownMenuItem<String>(
                                        value: brand,
                                        child: Text(brand),
                                      ))
                                  .toList(),
                              onChanged: (value) {
                                setState(() {
                                  selectedBrand = value;
                                  selectedProduct = null;
                                });
                              },
                            ),
                          const SizedBox(height: 10),
                          if (selectedBrand != null)
                            DropdownButton<String>(
                              value: selectedProduct,
                              hint: const Text('Choisir une référence'),
                              dropdownColor: Colors.blueGrey[900],
                              style: const TextStyle(color: Colors.white),
                              isExpanded: true,
                              items: getProductsForBrand(selectedBrand!)
                                  .map((product) => DropdownMenuItem<String>(
                                        value: product,
                                        child: Text(product),
                                      ))
                                  .toList(),
                              onChanged: (value) {
                                setState(() {
                                  selectedProduct = value;
                                });
                              },
                            ),
                          const SizedBox(height: 16),
                          if (selectedProduct != null)
                            _buildProductDetails(getSelectedItem()),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 0,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];
            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final tween = Tween(
                    begin: const Offset(-1.0, 0.0),
                    end: Offset.zero,
                  ).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )
    
    );
  }
}