import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:wifi_scan/wifi_scan.dart';
import 'dart:math';
import '../common/bottom_nav_bar.dart';
import 'home_page.dart';
import 'catalogue_page.dart';
import 'light_menu_page.dart';
import 'structure_menu_page.dart';
import 'sound_menu_page.dart';
import 'video_menu_page.dart';
import 'electricite_menu_page.dart';

class DiversMenuPage extends StatefulWidget {
  const DiversMenuPage({super.key}
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );

  @override
  State<DiversMenuPage> createState() => _DiversMenuPageState(
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
}

class _DiversMenuPageState extends State<DiversMenuPage> with SingleTickerProviderStateMixin {
  String result = '';
  WiFiAccessPoint? selectedNetwork;
  double downloadSpeed = 0;
  double uploadSpeed = 0;
  late TabController _tabController;

  @override
  void initState() {
    super.initState(
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    _tabController = TabController(length: 3, vsync: this
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    detectConnectedNetwork(
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
  }

  Future<void> detectConnectedNetwork() async {
    try {
      final networks = await WiFiScan.instance.getScannedResults(
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
      setState(() {
        selectedNetwork = networks.isNotEmpty ? networks.first : null;
      }
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    } catch (e) {
      setState(() {
        selectedNetwork = null;
      }
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    }
  }

  Future<void> testBandwidth() async {
    setState(() => result = 'Test de bande passante en cours...'
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    final stopwatch = Stopwatch()..start(
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    final response = await http.get(Uri.parse('https://speed.hetzner.de/100MB.bin')
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    stopwatch.stop(
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    if (response.statusCode == 200) {
      final timeInSeconds = stopwatch.elapsedMilliseconds / 1000;
      final speedMbps = (response.contentLength ?? 0) * 8 / timeInSeconds / 1000000;
      setState(() {
        downloadSpeed = speedMbps;
        uploadSpeed = speedMbps / 10;
        result = 'Download : ${downloadSpeed.toStringAsFixed(2)} Mbps\nUpload : ${uploadSpeed.toStringAsFixed(2)} Mbps';
      }
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    } else {
      setState(() => result = 'Erreur lors du téléchargement'
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    }
  }

  Widget _buildGauge(double value, String label) {
    return Column(
      children: [
        CustomPaint(
          size: const Size(130, 130),
          painter: _GaugePainter(value: value),
        ),
        const SizedBox(height: 8),
        Text(
          '$label\n${value.toStringAsFixed(1)} Mbps',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white, fontSize: 14),
        ),
      ],
    
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/background.jpg'),
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(Colors.black54, BlendMode.darken),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Container(
                  color: Colors.black.withOpacity(0.4),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const Text('Réseau', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                GestureDetector(
                  onTap: () {
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const HomePage())
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
                  },
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.4),
                      border: Border.all(color: Colors.white, width: 2),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Image.asset('assets/logo.png', height: 60),
                  ),
                ),
                const SizedBox(height: 10),
                TabBar(
                  controller: _tabController,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.grey,
                  tabs: const [
                    Tab(text: 'Bande passante'),
                    Tab(text: 'Scan réseau'),
                    Tab(text: 'Ping'),
                  ],
                ),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Container(
                          padding: const EdgeInsets.all(16.0),
                          decoration: BoxDecoration(
                            color: const Color(0xFF0A1128).withOpacity(0.5),
                            border: Border.all(color: const Color(0xFF0A1128), width: 2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                selectedNetwork != null ?
                                  'Réseau détecté : ${selectedNetwork!.ssid}' :
                                  'Aucun réseau détecté',
                                style: const TextStyle(color: Colors.white, fontSize: 16),
                              ),
                              const SizedBox(height: 10),
                              ElevatedButton(
                                onPressed: testBandwidth,
                                child: const Text('Lancer le test'),
                              ),
                              const SizedBox(height: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  _buildGauge(downloadSpeed, 'Download'),
                                  _buildGauge(uploadSpeed, 'Upload'),
                                ],
                              ),
                              const SizedBox(height: 20),
                              Text(result, style: const TextStyle(color: Colors.white)),
                            ],
                          ),
                        ),
                      ),
                      Center(child: Text('Scan réseau local à venir', style: TextStyle(color: Colors.white))),
                      Center(child: Text('Fonction Ping à venir', style: TextStyle(color: Colors.white))),
                    ],
                  ),
                )
              ],
            ),
          ),
        ],
      ),
      // bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blueGrey[900],
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.grey,
        currentIndex: 5,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.push(context, MaterialPageRoute(builder: (context) => const CataloguePage())
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
              break;
            case 1:
              Navigator.push(context, MaterialPageRoute(builder: (context) => const LightMenuPage())
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
              break;
            case 2:
              Navigator.push(context, MaterialPageRoute(builder: (context) => const StructureMenuPage())
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
              break;
            case 3:
              Navigator.push(context, MaterialPageRoute(builder: (context) => const SoundMenuPage())
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
              break;
            case 4:
              Navigator.push(context, MaterialPageRoute(builder: (context) => const VideoMenuPage())
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
              break;
            case 5:
              Navigator.push(context, MaterialPageRoute(builder: (context) => const ElectriciteMenuPage())
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
              break;
            case 6:
              Navigator.push(context, MaterialPageRoute(builder: (context) => const DiversMenuPage())
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
              break;
          }
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
          BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
          BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
          BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
          BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
          BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
          BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
        ],
      ),
    
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
  }
}

class _GaugePainter extends CustomPainter {
  final double value;
  _GaugePainter({required this.value}
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    final radius = size.width / 2;
    final backgroundPaint = Paint()
      ..color = Colors.grey.shade800
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, radius, backgroundPaint
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );

    final needlePaint = Paint()
      ..color = Colors.red
      ..strokeWidth = 4;

    final angle = (pi * (value / 100)).clamp(0, pi
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    final needleEnd = Offset(center.dx + radius * cos(angle - pi), center.dy + radius * sin(angle - pi)
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
    canvas.drawLine(center, needleEnd, needlePaint
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blueGrey[900],
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          currentIndex: 6,
          onTap: (index) {
            final pages = [
              const CataloguePage(),
              const LightMenuPage(),
              const StructureMenuPage(),
              const SoundMenuPage(),
              const VideoMenuPage(),
              const ElectriciteMenuPage(),
              const DiversMenuPage(),
            ];

            Navigator.push(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => pages[index],
                transitionsBuilder: (_, animation, __, child) {
                  final begin = Offset(
                    index == 0 || index == 1 ? -1.0 : 1.0, // gauche pour Catalogue & Lumière, droite pour Electricité & Réseau
                    0,
                  );
                  final end = Offset.zero;
                  final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: Curves.easeInOut));
                  return SlideTransition(position: animation.drive(tween), child: child);
                },
                transitionDuration: const Duration(milliseconds: 400),
              ),
            );
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
            BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
            BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
            BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
            BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
            BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
          ],
        )

    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
