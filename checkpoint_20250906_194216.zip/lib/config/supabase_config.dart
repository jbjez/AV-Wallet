class SupabaseConfig {
  static const String url = 'https://sjwaoemczpzwlijljozk.supabase.co';
  static const String anonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNqd2FvZW1jenB6d2xpamxqb3prIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY5MjYxMjksImV4cCI6MjA3MjUwMjEyOX0.xWAwKbAcsKQviBz31HmcCRY5XhT1WPy9tIAliyqqMlg';
  static const String scheme = 'io.supabase.avwallet';
  static const String redirectUrl = '$scheme://login-callback/';
} 