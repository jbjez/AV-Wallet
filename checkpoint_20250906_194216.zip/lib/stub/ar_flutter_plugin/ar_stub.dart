class ARSessionManager {}
class ARObjectManager {}
class ARAnchorManager {}
class ARLocationManager {}
class ARNode {
  ARNode({required String uri});
}