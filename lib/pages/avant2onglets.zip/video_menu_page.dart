// Nouvelle version stylée de VideoMenuPage avec sélection marque → produit en slide + outils calculs

import 'package:flutter/material.dart';
import 'home_page.dart';
import 'catalogue_page.dart';
import 'light_menu_page.dart';
import 'structure_menu_page.dart';
import 'sound_menu_page.dart';
import 'electricite_menu_page.dart';
import 'divers_menu_page.dart';
import 'ar_measure_page.dart';
import '../models/catalogue_item.dart';
import '../models/lens.dart';
import '../data/catalogue_data.dart';

class VideoMenuPage extends StatefulWidget {
  const VideoMenuPage({super.key});

  @override
  State<VideoMenuPage> createState() => _VideoMenuPageState();
}

class _VideoMenuPageState extends State<VideoMenuPage> with TickerProviderStateMixin {
  String? selectedBrand;
  CatalogueItem? selectedProjector;
  double largeur = 5;
  double distance = 10;
  late final Map<String, List<CatalogueItem>> brandToProducts;
  late final AnimationController _slideController;

  @override
  void initState() {
    super.initState();
    final projectors = catalogueData
        .where((item) => item.categorie == 'Vidéo' && item.sousCategorie == 'Videoprojection')
        .toList();
    brandToProducts = {};
    for (var item in projectors) {
      brandToProducts.putIfAbsent(item.marque, () => []).add(item);
    }
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
  }

  Lens? getRecommendedLens(CatalogueItem proj, double ratio) {
    if (proj.optiques == null || proj.optiques!.isEmpty) return null;

    final validLenses = proj.optiques!
        .map((lens) => MapEntry(lens, _parseRatio(lens.ratio)))
        .where((entry) => entry.value != -1)
        .toList();

    final lensesInRange = validLenses.where((entry) => entry.value >= ratio).toList();
    if (lensesInRange.isNotEmpty) {
      lensesInRange.sort((a, b) => (a.value - ratio).abs().compareTo((b.value - ratio).abs()));
      return lensesInRange.first.key;
    }

    final lowerLenses = validLenses.where((entry) => entry.value < ratio).toList();
    if (lowerLenses.isNotEmpty) {
      lowerLenses.sort((a, b) => (ratio - a.value).abs().compareTo((ratio - b.value).abs()));
      return lowerLenses.first.key;
    }

    return null;
  }

  double _parseRatio(String ratioStr) {
    try {
      if (ratioStr.contains('–') || ratioStr.contains('-')) {
        final parts = ratioStr.replaceAll(',', '.').split(RegExp(r'[–-]'));
        final min = double.tryParse(parts[0].trim().split(':').last) ?? -1;
        final max = double.tryParse(parts[1].trim().split(':').last) ?? -1;
        return (min + max) / 2;
      } else {
        return double.tryParse(ratioStr.trim().split(':').last.replaceAll(',', '.')) ?? -1;
      }
    } catch (_) {
      return -1;
    }
  }

  void _navigateTo(int index) {
    final pages = [
      const CataloguePage(),
      const LightMenuPage(),
      const StructureMenuPage(),
      const SoundMenuPage(),
      const VideoMenuPage(),
      const ElectriciteMenuPage(),
      const DiversMenuPage(),
    ];
    Offset beginOffset;
    if (index == 0 || index == 1) {
      beginOffset = const Offset(-1.0, 0.0);
    } else if (index == 5 || index == 6) {
      beginOffset = const Offset(1.0, 0.0);
    } else {
      beginOffset = Offset.zero;
    }
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => pages[index],
        transitionsBuilder: (_, animation, __, child) {
          if (beginOffset == Offset.zero) {
            return FadeTransition(opacity: animation, child: child);
          } else {
            final tween = Tween(begin: beginOffset, end: Offset.zero)
                .chain(CurveTween(curve: Curves.easeInOut));
            return SlideTransition(position: animation.drive(tween), child: child);
          }
        },
        transitionDuration: const Duration(milliseconds: 400),
      ),
    );
  }

  @override
  void dispose() {
    _slideController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final brands = brandToProducts.keys.toList()..sort();
    final ratio = distance / largeur;
    final recommendation = selectedProjector != null ? getRecommendedLens(selectedProjector!, ratio) : null;

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: Container(
          color: Colors.black.withOpacity(0.4),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
              const Text('Vidéo',
                  style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          Opacity(
            opacity: 0.5,
            child: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/background.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 8),
                GestureDetector(
                  onTap: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const HomePage()),
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.4),
                      border: Border.all(color: Colors.white, width: 2),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Image.asset('assets/logo.png', height: 60),
                  ),
                ),
                const SizedBox(height: 16),
                Padding(
  padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 4),
  child: GestureDetector(
    onTap: () async {
      final selected = await showDialog<CatalogueItem>(
        context: context,
        builder: (context) {
          String? tempBrand;
          return StatefulBuilder(
            builder: (context, setState) {
              final brands = brandToProducts.keys.toList()..sort();
              final products = tempBrand != null ? brandToProducts[tempBrand]! : [];
              return AlertDialog(
                backgroundColor: Colors.blueGrey[900]?.withOpacity(0.5),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                title: Text(
                  tempBrand == null ? 'Choisir une marque' : 'Choisir un modèle',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14, // plus petit que normal
                  ),
                ),
content: ConstrainedBox(
  constraints: const BoxConstraints(maxHeight: 200, maxWidth: 250),
  child: SingleChildScrollView(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: (tempBrand == null ? brands : products).map((item) {
        final text = tempBrand == null ? item : item.produit;
        return ListTile(
          title: Text(
            text,
            style: const TextStyle(color: Colors.white, fontSize: 13),
          ),
          onTap: () {
            if (tempBrand == null) {
              setState(() => tempBrand = item);
            } else {
              Navigator.of(context).pop(item);
            }
          },
        );
      }).toList(),
    ),
  ),
),
actions: tempBrand != null
    ? [
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(
            style: TextButton.styleFrom(
              foregroundColor: Colors.grey,
              padding: EdgeInsets.symmetric(horizontal: 30, vertical: 4),
              backgroundColor: Colors.transparent,
              minimumSize: Size(60, 28),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            onPressed: () => setState(() => tempBrand = null),
            child: const Text('Retour'),
          ),
        )
      ]
    : null,
            
  
              );
            },
          );
        },
      );
      if (selected != null) {
        setState(() => selectedProjector = selected);
      }
    },
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.5),
        border: Border.all(color: Colors.white),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            selectedProjector != null
                ? '${selectedProjector!.marque} - ${selectedProjector!.produit}'
                : 'Choisir un vidéoprojecteur',
            style: const TextStyle(color: Colors.white, fontSize: 13),
          ),
          const Icon(Icons.arrow_drop_down, color: Colors.white),
        ],
      ),
    ),
  ),
),

                const SizedBox(height: 16),
                Text('Largeur image : ${largeur.toStringAsFixed(1)} m',
                    style: const TextStyle(color: Colors.white)),
                Slider(
                  value: largeur,
                  min: 1,
                  max: 15,
                  divisions: 28,
                  label: largeur.toStringAsFixed(1),
                  onChanged: (value) {
                    setState(() {
                      largeur = value;
                    });
                  },
                ),
                Text('Distance projecteur : ${distance.toStringAsFixed(1)} m',
                    style: const TextStyle(color: Colors.white)),
                Slider(
                  value: distance,
                  min: 1,
                  max: 50,
                  divisions: 49,
                  label: distance.toStringAsFixed(1),
                  onChanged: (value) {
                    setState(() {
                      distance = value;
                    });
                  },
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ArMeasurePage()),
                    );
                  },
                  child: const Text('Mesurer la distance en AR'),
                ),
                const SizedBox(height: 16),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A1128).withOpacity(0.5),
                    border: Border.all(color: const Color(0xFF0A1128), width: 2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Ratio image : ${ratio.toStringAsFixed(2)}:1',
                          style: const TextStyle(color: Colors.white)),
                      if (selectedProjector != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: recommendation != null
                              ? Text(
                                  'Optique recommandée : ${recommendation.reference} (${recommendation.ratio})',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold),
                                )
                              : const Text('⚠️ Aucune optique disponible.',
                                  style: TextStyle(
                                      color: Colors.redAccent,
                                      fontWeight: FontWeight.bold)),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blueGrey[900],
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.grey,
        currentIndex: 4,
        onTap: _navigateTo,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Catalogue'),
          BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Lumière'),
          BottomNavigationBarItem(icon: Icon(Icons.account_tree), label: 'Structure'),
          BottomNavigationBarItem(icon: Icon(Icons.volume_up), label: 'Son'),
          BottomNavigationBarItem(icon: Icon(Icons.videocam), label: 'Vidéo'),
          BottomNavigationBarItem(icon: Icon(Icons.bolt), label: 'Électricité'),
          BottomNavigationBarItem(icon: Icon(Icons.more_horiz), label: 'Divers'),
        ],
      ),
    );
  }
}
